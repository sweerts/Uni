UML Validator
-------------

Der UML Validator ist ein experimentelles Werkzeug zur Validierung von UML Klassendiagrammen im UMLet-Format.
Ursprünglich sollte eine erste lauffähige Version zum nächsten Wintersemester bereitstehen, aber aufgrund der aktuellen Situation habe ich mich entschlossen, eine frühe Version bereits jetzt schnell verfügbar zu machen. Diese Version hat nur einen geringen Funktionsumfang, enthält dafür aber mit Sicherheit noch diverse Bugs.
Bug-Meldungen, Feature-Requests oder Erfahrungsberichte könnt Ihr gerne im Forum unter Sebstlernaufgaben posten.

Verwendung:
1. Aktuelles Java (mindestens 13) installieren, Pfad und Classpath einrichten (das geschieht meistens automatisch).
2. UML Validator herunterladen und entpacken.
3. Die Selbstlernaufgabe in UMLet modellieren und abspeichern.
4. Die passende Validerungs-.class-Datei herunterladen (z.B. für Aufgabe OMP-SST-01 ist das die OMP_SST_01.class).
5. Den UML Validator starten, z.B. über die run.bat/run.sh.
6. Die UMLet-Datei und die .class-Datei auswählen und auf 'Validate' klicken.

Der UML Validator ist momentan ausschließlich für die Verwendung in OMP gedacht und darf nicht weitergegeben werden. Die Verwendung erfolgt auf eigene Gefahr.

(c) 2020 C. Schönberg