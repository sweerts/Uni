set +v
java -jar UMLValidator.jar ExampleValidation.uxf ./ExampleValidation.class
sleep