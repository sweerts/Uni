
public interface Observer {
	
	void update(Observable who, ShipEvent what);

}
