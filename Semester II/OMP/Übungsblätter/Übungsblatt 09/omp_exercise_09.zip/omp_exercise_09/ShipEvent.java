
public enum ShipEvent {
	
	NO_EVENT,
	SET_SAILS,
	STRIKE_SAILS,
	LOAD_CANNONS,
	FIRE_CANNONS,
	TURN_LEFT,
	TURN_RIGHT;

}
