public abstract class Fibonacci {
	
	public abstract long calculate(int n);
	
}
