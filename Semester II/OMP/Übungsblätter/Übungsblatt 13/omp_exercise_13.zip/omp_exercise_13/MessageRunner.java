import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class MessageRunner {

	public static void main(String[] args) {
		KieServices kieServices = KieServices.Factory.get();
		KieContainer kContainer = kieServices.getKieClasspathContainer();
		KieSession kSession = kContainer.newKieSession("ksession-rules");

		kSession.insert(new Person("Frodo"));
		kSession.insert(new Person("Samwise"));
		kSession.insert(new Person("Peregrin"));
		kSession.insert(new Person("Meriadoc"));
		kSession.insert(new Message("Frodo", "Samwise", "Hello Samwise."));
		kSession.insert(new Message("Peregrin", "Samwise", "Hello Samwise."));
		kSession.insert(new Message("Peregrin", "Meriadoc", "Hello Meriadoc."));
		kSession.insert(new Message("Frodo", "Meriadoc", "Hello Meriadoc."));
		kSession.insert(new Message("Groot", "Rocket", "I am Groot!"));
		kSession.insert(new Message("Gandalf the Grey", "Gandalf the White", "Am I talking to myself?"));
		kSession.fireAllRules();
		kSession.dispose();
	}

}
