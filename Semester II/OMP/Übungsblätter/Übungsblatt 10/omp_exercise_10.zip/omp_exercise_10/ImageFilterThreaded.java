import java.awt.Color;

public class ImageFilterThreaded extends ImageFilter {

	@Override
	protected Color[][] filterMatrix(float[][] filter) {
		//TODO implement this
		return super.filterMatrix(filter);
	}

}
