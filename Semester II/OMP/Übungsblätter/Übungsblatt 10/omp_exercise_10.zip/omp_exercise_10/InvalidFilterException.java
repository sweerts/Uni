public class InvalidFilterException extends Exception {

	private static final long serialVersionUID = 1L;

}
