public class QuickSortThreaded extends QuickSort {

	/**
	 * sortiert das uebergebene Array in aufsteigender Reihenfolge
	 * gemaess dem QuickSort-Algorithmus (parallel!)
	 */
	public static void sort(int[] numbers) {
		//TODO implement this
		QuickSort.sort(numbers);
	}

	/**
	 * der Quicksort-Algorithmus wird auf dem Array zwischen den
	 * angegebenen Indizes ausgefuehrt
	 */
	protected void quickSort(int[] numbers, int leftIndex, int rightIndex) {
		//TODO implement this
		super.quickSort(number, leftIndex, rightIndex);
	}

}
