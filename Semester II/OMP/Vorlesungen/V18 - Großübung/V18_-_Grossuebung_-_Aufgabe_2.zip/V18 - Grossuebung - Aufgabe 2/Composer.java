import java.util.Random;

public class Composer extends Musician {

	private final Random random = new Random();

	public Composer(SheetMusic music) {
		super(music);
	}
	
	public void compose() {
		music.startComposing();
		for (int i = 0; i < 1 + random.nextInt(5); i++) {
			music.add(music.new Note(getRandomName(), getRandomDuration()));
		}
		music.stopComposing();
	}

	private SheetMusic.NoteName getRandomName() {
		return SheetMusic.NoteName.values()[random.nextInt(SheetMusic.NoteName.values().length)];
	}

	private SheetMusic.NoteDuration getRandomDuration() {
		return SheetMusic.NoteDuration.values()[random.nextInt(SheetMusic.NoteDuration.values().length)];
	}
	
}