package de.uni_oldenburg.inf.omp.lecture.l11;

public class InvalidDeckConfigurationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidDeckConfigurationException(Exception e) {
		super(e);
	}

}
