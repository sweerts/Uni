package de.uni_oldenburg.inf.omp.lecture.l11;

public interface ComparableCard<T extends ComparableCard<? super T>> extends Comparable<T>, Card {

}
