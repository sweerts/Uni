package de.uni_oldenburg.inf.omp.lecture.l11;

public class InvalidSuitException extends InvalidCardException {

	private static final long serialVersionUID = 1L;

	public InvalidSuitException(String s) {
		super(s);
	}

}
