package de.uni_oldenburg.inf.omp.lecture.l11;

public class DuplicateCardException extends InvalidCardException {

	private static final long serialVersionUID = 1L;

	public DuplicateCardException(String s) {
		super(s);
	}

}
