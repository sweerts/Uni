package de.uni_oldenburg.inf.omp.lecture.l11;

public interface Card {

}
