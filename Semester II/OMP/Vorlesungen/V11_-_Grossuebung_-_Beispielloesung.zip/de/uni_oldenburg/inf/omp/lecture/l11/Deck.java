package de.uni_oldenburg.inf.omp.lecture.l11;

public interface Deck<T extends Card> {
	
	void add(T card) throws InvalidCardException;

}
