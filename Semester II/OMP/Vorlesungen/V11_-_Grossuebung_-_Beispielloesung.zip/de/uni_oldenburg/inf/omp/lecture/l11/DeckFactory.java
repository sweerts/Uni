package de.uni_oldenburg.inf.omp.lecture.l11;

public abstract class DeckFactory<T extends Card> {
	
	public abstract Deck<T> createDeck();

}
