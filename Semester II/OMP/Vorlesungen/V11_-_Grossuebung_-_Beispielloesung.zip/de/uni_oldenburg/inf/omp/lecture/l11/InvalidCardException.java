package de.uni_oldenburg.inf.omp.lecture.l11;

public class InvalidCardException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidCardException() {
		super();
	}
	
	public InvalidCardException(String s) {
		super(s);
	}

}
