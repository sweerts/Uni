package de.uni_oldenburg.inf.omp.lecture.l11;

public class InvalidRankException extends InvalidCardException {

	private static final long serialVersionUID = 1L;

	public InvalidRankException(String s) {
		super(s);
	}

}
