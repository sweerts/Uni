package de.uni_oldenburg.inf.omp.lecture.l11;

import java.util.ArrayList;
import java.util.List;

public abstract class FrenchDeck implements Deck<FrenchCard> {
	
	protected List<FrenchCard> cards = new ArrayList<>();

}
