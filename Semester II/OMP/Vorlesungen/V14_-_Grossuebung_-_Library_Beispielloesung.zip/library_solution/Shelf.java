import java.util.Collection;

public interface Shelf<T> {
	
	Collection<T> getItems();

}
