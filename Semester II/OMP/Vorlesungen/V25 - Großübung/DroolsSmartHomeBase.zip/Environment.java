package de.uni_oldenburg.inf.omp.drools.smart_home;

import java.util.Random;

public class Environment {
	
	private static final int INITIAL_TEMP = 20;
	private static final int MIN_TEMP = 10;
	private static final int MAX_TEMP = 30;
	
	private int lastTemp = INITIAL_TEMP;
	private Random rand = new Random();
	
	private int baseTemperature = 0;
	
	public int getTemperature() {
		int change = rand.nextInt(3) - 1;
		if (lastTemp <= MIN_TEMP && change == -1) {
			change = 0;
		} else if (lastTemp >= MAX_TEMP && change == 1) {
			change = 0;
		}
		lastTemp += change;
		System.out.println("temp = " + (lastTemp + baseTemperature));
		return lastTemp + baseTemperature;
	}

	public int getBaseTemperature() {
		return baseTemperature;
	}

	public void setBaseTemperature(int baseTemperature) {
		this.baseTemperature = baseTemperature;
	}

}
