package de.uni_oldenburg.inf.omp.drools.smart_home;

public class Thermometer {
	
	private Environment environment;

	public Thermometer(Environment env) {
		super();
		this.environment = env;
	}

	public Environment getEnv() {
		return environment;
	}

	public void setEnv(Environment env) {
		this.environment = env;
	}
	
	public Temperature getTemperature() {
		return new Temperature(environment.getTemperature());
	}
}
