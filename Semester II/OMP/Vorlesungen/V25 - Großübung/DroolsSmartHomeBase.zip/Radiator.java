package de.uni_oldenburg.inf.omp.drools.smart_home;

public class Radiator {
	
	private int level;
	private Environment environment;
	
	public Radiator(int level, Environment env) {
		super();
		this.level = level;
		this.environment = env;
	}
	
	public int getLevel() {
		return level;
	}
	
	public void setLevel(int level) {
		this.level = level;
		environment.setBaseTemperature(level);
	}
	
	public Environment getEnv() {
		return environment;
	}
	
	public void setEnv(Environment env) {
		this.environment = env;
	}

}
