package de.uni_oldenburg.inf.omp.drools.smart_home;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class TemperatureController {

	public static void main(String[] args) {
		KieServices kieServices = KieServices.Factory.get();
		KieContainer kContainer = kieServices.getKieClasspathContainer();
		KieSession kSession = kContainer.newKieSession("ksession-rules");

		Environment env = new Environment();
		Thermometer thermometer = new Thermometer(env);
		Radiator radiator = new Radiator(0, env);
		kSession.insert(thermometer);
		kSession.insert(radiator);
		kSession.insert(thermometer.getTemperature());
		
		kSession.fireAllRules();
		kSession.dispose();
	}

}
