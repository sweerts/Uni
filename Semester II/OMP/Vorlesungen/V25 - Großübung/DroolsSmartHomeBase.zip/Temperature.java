package de.uni_oldenburg.inf.omp.drools.smart_home;

public class Temperature {
	
	private int value;

	public Temperature(int value) {
		super();
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

}
